import { 
  InsertMirna, Mirna, InsertLncrna, Lncrna,
  InsertInteraction, Interaction, InteractionWithDetails,
  PredictionInput, PredictionResult, SearchQuery,
  User, InsertUser, mirnas, lncrnas, interactions, users
} from "@shared/schema";
import { IStorage } from "./storage";
import { db } from "./db";
import { eq, like, or } from "drizzle-orm";

// Database-backed implementation
export class DatabaseStorage implements IStorage {
  // User-related methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // miRNA-related methods
  async getMirna(id: number): Promise<Mirna | undefined> {
    const [mirna] = await db.select().from(mirnas).where(eq(mirnas.id, id));
    return mirna || undefined;
  }

  async getMirnaByName(name: string): Promise<Mirna | undefined> {
    const [mirna] = await db
      .select()
      .from(mirnas)
      .where(
        or(
          eq(mirnas.name, name),
          like(mirnas.name, `%${name}%`)
        )
      );
    return mirna || undefined;
  }

  async createMirna(insertMirna: InsertMirna): Promise<Mirna> {
    const [mirna] = await db.insert(mirnas).values(insertMirna).returning();
    return mirna;
  }

  async getAllMirnas(): Promise<Mirna[]> {
    return db.select().from(mirnas);
  }

  // lncRNA-related methods
  async getLncrna(id: number): Promise<Lncrna | undefined> {
    const [lncrna] = await db.select().from(lncrnas).where(eq(lncrnas.id, id));
    return lncrna || undefined;
  }

  async getLncrnaByName(name: string): Promise<Lncrna | undefined> {
    const [lncrna] = await db
      .select()
      .from(lncrnas)
      .where(
        or(
          eq(lncrnas.name, name),
          like(lncrnas.name, `%${name}%`)
        )
      );
    return lncrna || undefined;
  }

  async createLncrna(insertLncrna: InsertLncrna): Promise<Lncrna> {
    const [lncrna] = await db.insert(lncrnas).values(insertLncrna).returning();
    return lncrna;
  }

  async getAllLncrnas(): Promise<Lncrna[]> {
    return db.select().from(lncrnas);
  }

  // Interaction-related methods
  async getInteraction(id: number): Promise<Interaction | undefined> {
    const [interaction] = await db.select().from(interactions).where(eq(interactions.id, id));
    return interaction || undefined;
  }

  async createInteraction(insertInteraction: InsertInteraction): Promise<Interaction> {
    const [interaction] = await db.insert(interactions).values(insertInteraction).returning();
    return interaction;
  }

  async getInteractionsByMirnaId(mirnaId: number): Promise<InteractionWithDetails[]> {
    const interactionsList = await db
      .select()
      .from(interactions)
      .where(eq(interactions.mirna_id, mirnaId));
      
    return Promise.all(interactionsList.map(async interaction => {
      const [mirna] = await db.select().from(mirnas).where(eq(mirnas.id, interaction.mirna_id));
      const [lncrna] = await db.select().from(lncrnas).where(eq(lncrnas.id, interaction.lncrna_id));
      
      if (!mirna || !lncrna) {
        throw new Error(`Related mirna or lncrna not found for interaction ${interaction.id}`);
      }
      
      return {
        interaction,
        mirna,
        lncrna
      };
    }));
  }

  async getInteractionsByLncrnaId(lncrnaId: number): Promise<InteractionWithDetails[]> {
    const interactionsList = await db
      .select()
      .from(interactions)
      .where(eq(interactions.lncrna_id, lncrnaId));
      
    return Promise.all(interactionsList.map(async interaction => {
      const [mirna] = await db.select().from(mirnas).where(eq(mirnas.id, interaction.mirna_id));
      const [lncrna] = await db.select().from(lncrnas).where(eq(lncrnas.id, interaction.lncrna_id));
      
      if (!mirna || !lncrna) {
        throw new Error(`Related mirna or lncrna not found for interaction ${interaction.id}`);
      }
      
      return {
        interaction,
        mirna,
        lncrna
      };
    }));
  }

  // Search-related methods
  async searchInteractions(query: SearchQuery): Promise<InteractionWithDetails[]> {
    let interactionsList: Interaction[] = [];
    
    if (query.searchType === "mirna") {
      // Search by miRNA name
      const mirna = await this.getMirnaByName(query.searchTerm);
      if (mirna) {
        interactionsList = await db
          .select()
          .from(interactions)
          .where(eq(interactions.mirna_id, mirna.id));
      }
    } else if (query.searchType === "lncrna" || query.searchType === "gene") {
      // Search by lncRNA name or gene ID
      const lncrna = await this.getLncrnaByName(query.searchTerm);
      if (lncrna) {
        interactionsList = await db
          .select()
          .from(interactions)
          .where(eq(interactions.lncrna_id, lncrna.id));
      } else if (query.searchType === "gene") {
        // Try to find lncRNAs with similar names to the gene ID
        const lncrnasList = await db
          .select()
          .from(lncrnas)
          .where(like(lncrnas.name, `%${query.searchTerm}%`));
        
        if (lncrnasList.length > 0) {
          const lncrnaIds = lncrnasList.map(lncrna => lncrna.id);
          
          // Build a WHERE condition for each lncrna id
          const whereConditions = lncrnaIds.map(id => eq(interactions.lncrna_id, id));
          
          interactionsList = await db
            .select()
            .from(interactions)
            .where(or(...whereConditions));
        }
      }
    }
    
    // Construct InteractionWithDetails objects
    return Promise.all(interactionsList.map(async interaction => {
      const [mirna] = await db.select().from(mirnas).where(eq(mirnas.id, interaction.mirna_id));
      const [lncrna] = await db.select().from(lncrnas).where(eq(lncrnas.id, interaction.lncrna_id));
      
      if (!mirna || !lncrna) {
        throw new Error(`Related mirna or lncrna not found for interaction ${interaction.id}`);
      }
      
      return {
        interaction,
        mirna,
        lncrna
      };
    }));
  }

  // Prediction-related methods
  async predictInteraction(input: PredictionInput): Promise<PredictionResult> {
    // Basic implementation of prediction algorithm
    const { mirnaSequence, lncrnaSequence, seedRegion, alignmentScore, mismatchPenalty, guWobble } = input;
    
    // Simple prediction logic
    // In a real implementation, this would use more complex algorithms
    const bindingSites = [];
    let totalMismatches = 0;
    let seedMatches = 0;
    
    // Sliding window approach for finding binding sites
    for (let i = 0; i <= lncrnaSequence.length - mirnaSequence.length; i++) {
      const lncrnaSubseq = lncrnaSequence.substring(i, i + mirnaSequence.length);
      
      // Count matches, mismatches, and G:U pairs
      let matches = 0;
      let mismatches = 0;
      let guPairs = 0;
      let seedMatch = true;
      
      // Alignment string
      let alignment = "";
      
      for (let j = 0; j < mirnaSequence.length; j++) {
        const mirnaBase = mirnaSequence[j].toUpperCase();
        const lncrnaBase = this.complementaryBase(lncrnaSubseq[j].toUpperCase());
        
        if (mirnaBase === lncrnaBase) {
          matches++;
          alignment += "|";
        } else if ((mirnaBase === "G" && lncrnaBase === "U") || (mirnaBase === "U" && lncrnaBase === "G")) {
          guPairs++;
          matches += guWobble;
          alignment += "○";
        } else {
          mismatches++;
          alignment += "×";
          
          // Check if mismatch is in seed region
          let seedStart = 1;
          let seedEnd = 7;
          
          if (seedRegion === "2-8") {
            seedStart = 1;
            seedEnd = 8;
          } else if (seedRegion === "1-8") {
            seedStart = 0;
            seedEnd = 8;
          }
          
          if (j >= seedStart && j < seedEnd) {
            seedMatch = false;
          }
        }
      }
      
      // Calculate score based on matches, mismatches, and G:U pairs
      const score = (matches - (mismatches * mismatchPenalty)) / mirnaSequence.length * 5;
      
      // Only consider if score is above threshold
      if (score >= alignmentScore) {
        bindingSites.push({
          mirnaStart: 0,
          mirnaEnd: mirnaSequence.length - 1,
          lncrnaStart: i,
          lncrnaEnd: i + mirnaSequence.length - 1,
          mirnaSequence,
          lncrnaSequence: lncrnaSubseq,
          alignment,
          score,
          mismatches,
          guPairs,
          seedMatch
        });
        
        totalMismatches += mismatches;
        if (seedMatch) seedMatches++;
      }
    }
    
    // Sort binding sites by score
    bindingSites.sort((a, b) => b.score - a.score);
    
    return {
      score: bindingSites.length > 0 ? bindingSites[0].score : 0,
      bindingSites,
      mirnaSequence,
      lncrnaSequence,
      totalMismatches,
      seedMatches
    };
  }
  
  // Helper method to get complementary base
  private complementaryBase(base: string): string {
    switch (base) {
      case "A": return "U";
      case "U": return "A";
      case "G": return "C";
      case "C": return "G";
      default: return "N";
    }
  }
}