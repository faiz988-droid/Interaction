import { Router, type Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { searchQuerySchema, predictionInputSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = Router();
  
  // API Routes - prefix with /api
  app.use("/api", apiRouter);
  
  // Get all miRNAs
  apiRouter.get("/mirnas", async (_req: Request, res: Response) => {
    try {
      const mirnas = await storage.getAllMirnas();
      res.json(mirnas);
    } catch (error) {
      console.error("Error fetching miRNAs:", error);
      res.status(500).json({ message: "Failed to fetch miRNAs" });
    }
  });
  
  // Get a specific miRNA by ID
  apiRouter.get("/mirnas/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid miRNA ID" });
      }
      
      const mirna = await storage.getMirna(id);
      if (!mirna) {
        return res.status(404).json({ message: "miRNA not found" });
      }
      
      res.json(mirna);
    } catch (error) {
      console.error("Error fetching miRNA:", error);
      res.status(500).json({ message: "Failed to fetch miRNA" });
    }
  });
  
  // Get all lncRNAs
  apiRouter.get("/lncrnas", async (_req: Request, res: Response) => {
    try {
      const lncrnas = await storage.getAllLncrnas();
      res.json(lncrnas);
    } catch (error) {
      console.error("Error fetching lncRNAs:", error);
      res.status(500).json({ message: "Failed to fetch lncRNAs" });
    }
  });
  
  // Get a specific lncRNA by ID
  apiRouter.get("/lncrnas/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid lncRNA ID" });
      }
      
      const lncrna = await storage.getLncrna(id);
      if (!lncrna) {
        return res.status(404).json({ message: "lncRNA not found" });
      }
      
      res.json(lncrna);
    } catch (error) {
      console.error("Error fetching lncRNA:", error);
      res.status(500).json({ message: "Failed to fetch lncRNA" });
    }
  });
  
  // Get interactions by miRNA ID
  apiRouter.get("/interactions/mirna/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid miRNA ID" });
      }
      
      const interactions = await storage.getInteractionsByMirnaId(id);
      res.json(interactions);
    } catch (error) {
      console.error("Error fetching interactions:", error);
      res.status(500).json({ message: "Failed to fetch interactions" });
    }
  });
  
  // Get interactions by lncRNA ID
  apiRouter.get("/interactions/lncrna/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid lncRNA ID" });
      }
      
      const interactions = await storage.getInteractionsByLncrnaId(id);
      res.json(interactions);
    } catch (error) {
      console.error("Error fetching interactions:", error);
      res.status(500).json({ message: "Failed to fetch interactions" });
    }
  });
  
  // Get a specific interaction by ID
  apiRouter.get("/interactions/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid interaction ID" });
      }
      
      const interaction = await storage.getInteraction(id);
      if (!interaction) {
        return res.status(404).json({ message: "Interaction not found" });
      }
      
      const mirna = await storage.getMirna(interaction.mirna_id);
      const lncrna = await storage.getLncrna(interaction.lncrna_id);
      
      if (!mirna || !lncrna) {
        return res.status(404).json({ message: "Related miRNA or lncRNA not found" });
      }
      
      res.json({
        interaction,
        mirna,
        lncrna
      });
    } catch (error) {
      console.error("Error fetching interaction:", error);
      res.status(500).json({ message: "Failed to fetch interaction" });
    }
  });
  
  // Search for interactions
  apiRouter.post("/search", async (req: Request, res: Response) => {
    try {
      const query = searchQuerySchema.parse(req.body);
      const results = await storage.searchInteractions(query);
      res.json(results);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      console.error("Error searching interactions:", error);
      res.status(500).json({ message: "Failed to search interactions" });
    }
  });
  
  // Predict miRNA-lncRNA interactions
  apiRouter.post("/predict", async (req: Request, res: Response) => {
    try {
      const predictionInput = predictionInputSchema.parse(req.body);
      const result = await storage.predictInteraction(predictionInput);
      res.json(result);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      console.error("Error predicting interactions:", error);
      res.status(500).json({ message: "Failed to predict interactions" });
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
