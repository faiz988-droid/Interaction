import { 
  InsertMirna, Mirna, InsertLncrna, Lncrna,
  InsertInteraction, Interaction, InteractionWithDetails,
  PredictionInput, PredictionResult, SearchQuery,
  User, InsertUser
} from "@shared/schema";

// Interface for all storage operations
export interface IStorage {
  // User operations (from original storage)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // miRNA operations
  getMirna(id: number): Promise<Mirna | undefined>;
  getMirnaByName(name: string): Promise<Mirna | undefined>;
  createMirna(mirna: InsertMirna): Promise<Mirna>;
  getAllMirnas(): Promise<Mirna[]>;
  
  // lncRNA operations
  getLncrna(id: number): Promise<Lncrna | undefined>;
  getLncrnaByName(name: string): Promise<Lncrna | undefined>;
  createLncrna(lncrna: InsertLncrna): Promise<Lncrna>;
  getAllLncrnas(): Promise<Lncrna[]>;
  
  // Interaction operations
  getInteraction(id: number): Promise<Interaction | undefined>;
  createInteraction(interaction: InsertInteraction): Promise<Interaction>;
  getInteractionsByMirnaId(mirnaId: number): Promise<InteractionWithDetails[]>;
  getInteractionsByLncrnaId(lncrnaId: number): Promise<InteractionWithDetails[]>;
  
  // Search operations
  searchInteractions(query: SearchQuery): Promise<InteractionWithDetails[]>;
  
  // Prediction operations
  predictInteraction(input: PredictionInput): Promise<PredictionResult>;
}

// In-memory implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private mirnas: Map<number, Mirna>;
  private lncrnas: Map<number, Lncrna>;
  private interactions: Map<number, Interaction>;
  
  private userId: number;
  private mirnaId: number;
  private lncrnaId: number;
  private interactionId: number;
  
  constructor() {
    this.users = new Map();
    this.mirnas = new Map();
    this.lncrnas = new Map();
    this.interactions = new Map();
    
    this.userId = 1;
    this.mirnaId = 1;
    this.lncrnaId = 1;
    this.interactionId = 1;
    
    this.initializeData();
  }

  // Initialize with sample data for Arabidopsis thaliana
  private initializeData() {
    // Sample miRNAs
    const mirnas: InsertMirna[] = [
      {
        name: "ath-miR156a-5p",
        sequence: "UGACAGAAGAGAGUGAGCAC",
        species: "Arabidopsis thaliana",
        source: "miRBase"
      },
      {
        name: "ath-miR156c-5p",
        sequence: "UUGACAGAAGAUAGAGAGCAC",
        species: "Arabidopsis thaliana",
        source: "miRBase"
      },
      {
        name: "ath-miR172e-3p",
        sequence: "GGAAUCUUGAUGAUGCUGCAU",
        species: "Arabidopsis thaliana",
        source: "miRBase"
      }
    ];

    // Sample lncRNAs
    const lncrnas: InsertLncrna[] = [
      {
        name: "ENSG00000228630",
        sequence: "ACUGCUCACUCUCUCUUGUCAAGUUACGGUACGUCGAUUAGCCGAUUACGCGUGC",
        species: "Arabidopsis thaliana",
        location: "Chr5: 23456789-23459876"
      },
      {
        name: "AT4G13570",
        sequence: "AUCGUCAGACGCUGCAGCUGACGCUGACGUCGCUGCGAUUGCGAUGCGAUGCGAUC",
        species: "Arabidopsis thaliana",
        location: "Chr4: 7654321-7657654"
      },
      {
        name: "AT5G03345",
        sequence: "GCUAGUCGUAGCUGAUGCGAUGCAUGGCUGCUGCUAGCUAGCUGCUACGCUACGC",
        species: "Arabidopsis thaliana",
        location: "Chr5: 1234567-1237890"
      }
    ];

    // Add miRNAs to storage
    mirnas.forEach(mirna => this.createMirna(mirna));
    
    // Add lncRNAs to storage
    lncrnas.forEach(lncrna => this.createLncrna(lncrna));
    
    // Add sample interactions
    this.createInteraction({
      mirna_id: 1, // ath-miR156a-5p
      lncrna_id: 1, // ENSG00000228630
      alignment: "UGACAGAAGAGAGUGAGCAC\n||||||||||||×||||||\nACUGCUCACUCUCUCUUGUCA",
      binding_site: "10-30",
      score: 4.2,
      method: "Computational",
      source: "Experimental"
    });
    
    this.createInteraction({
      mirna_id: 2, // ath-miR156c-5p
      lncrna_id: 2, // AT4G13570
      alignment: "UUGACAGAAGAUAGAGAGCAC\n|||||||||×||||||||||\nAUCGUCAGACGCUGCAGCUGA",
      binding_site: "5-25",
      score: 3.8,
      method: "Computational",
      source: "Predicted"
    });
    
    this.createInteraction({
      mirna_id: 1, // ath-miR156a-5p
      lncrna_id: 3, // AT5G03345
      alignment: "UGACAGAAGAGAGUGAGCAC\n||||||||×||||||×|||\nGCUAGUCGUAGCUGAUGCGAU",
      binding_site: "1-21",
      score: 2.9,
      method: "Computational",
      source: "Predicted"
    });
  }

  // User-related methods (from original storage)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // miRNA-related methods
  async getMirna(id: number): Promise<Mirna | undefined> {
    return this.mirnas.get(id);
  }

  async getMirnaByName(name: string): Promise<Mirna | undefined> {
    return Array.from(this.mirnas.values()).find(
      (mirna) => mirna.name.toLowerCase() === name.toLowerCase()
    );
  }

  async createMirna(insertMirna: InsertMirna): Promise<Mirna> {
    const id = this.mirnaId++;
    // Ensure species is provided (default to Arabidopsis thaliana if not)
    const species = insertMirna.species || "Arabidopsis thaliana";
    const mirna: Mirna = { 
      ...insertMirna, 
      id,
      species
    };
    this.mirnas.set(id, mirna);
    return mirna;
  }

  async getAllMirnas(): Promise<Mirna[]> {
    return Array.from(this.mirnas.values());
  }

  // lncRNA-related methods
  async getLncrna(id: number): Promise<Lncrna | undefined> {
    return this.lncrnas.get(id);
  }

  async getLncrnaByName(name: string): Promise<Lncrna | undefined> {
    return Array.from(this.lncrnas.values()).find(
      (lncrna) => lncrna.name.toLowerCase() === name.toLowerCase()
    );
  }

  async createLncrna(insertLncrna: InsertLncrna): Promise<Lncrna> {
    const id = this.lncrnaId++;
    // Ensure species is provided (default to Arabidopsis thaliana if not)
    const species = insertLncrna.species || "Arabidopsis thaliana";
    // Ensure location is not undefined
    const location = insertLncrna.location ?? null;
    
    const lncrna: Lncrna = { 
      ...insertLncrna, 
      id,
      species,
      location
    };
    this.lncrnas.set(id, lncrna);
    return lncrna;
  }

  async getAllLncrnas(): Promise<Lncrna[]> {
    return Array.from(this.lncrnas.values());
  }

  // Interaction-related methods
  async getInteraction(id: number): Promise<Interaction | undefined> {
    return this.interactions.get(id);
  }

  async createInteraction(insertInteraction: InsertInteraction): Promise<Interaction> {
    const id = this.interactionId++;
    const interaction: Interaction = { ...insertInteraction, id };
    this.interactions.set(id, interaction);
    return interaction;
  }

  async getInteractionsByMirnaId(mirnaId: number): Promise<InteractionWithDetails[]> {
    const interactions = Array.from(this.interactions.values()).filter(
      (interaction) => interaction.mirna_id === mirnaId
    );
    
    return Promise.all(interactions.map(async (interaction) => {
      const mirna = await this.getMirna(interaction.mirna_id);
      const lncrna = await this.getLncrna(interaction.lncrna_id);
      
      if (!mirna || !lncrna) {
        throw new Error(`Related mirna or lncrna not found for interaction ${interaction.id}`);
      }
      
      return {
        interaction,
        mirna,
        lncrna
      };
    }));
  }

  async getInteractionsByLncrnaId(lncrnaId: number): Promise<InteractionWithDetails[]> {
    const interactions = Array.from(this.interactions.values()).filter(
      (interaction) => interaction.lncrna_id === lncrnaId
    );
    
    return Promise.all(interactions.map(async (interaction) => {
      const mirna = await this.getMirna(interaction.mirna_id);
      const lncrna = await this.getLncrna(interaction.lncrna_id);
      
      if (!mirna || !lncrna) {
        throw new Error(`Related mirna or lncrna not found for interaction ${interaction.id}`);
      }
      
      return {
        interaction,
        mirna,
        lncrna
      };
    }));
  }

  // Search-related methods
  async searchInteractions(query: SearchQuery): Promise<InteractionWithDetails[]> {
    let filteredInteractions: Interaction[] = [];
    
    if (query.searchType === "mirna") {
      const mirna = await this.getMirnaByName(query.searchTerm);
      if (mirna) {
        filteredInteractions = Array.from(this.interactions.values()).filter(
          (interaction) => interaction.mirna_id === mirna.id
        );
      }
    } else if (query.searchType === "lncrna" || query.searchType === "gene") {
      const lncrna = await this.getLncrnaByName(query.searchTerm);
      if (lncrna) {
        filteredInteractions = Array.from(this.interactions.values()).filter(
          (interaction) => interaction.lncrna_id === lncrna.id
        );
      }
    }
    
    return Promise.all(filteredInteractions.map(async (interaction) => {
      const mirna = await this.getMirna(interaction.mirna_id);
      const lncrna = await this.getLncrna(interaction.lncrna_id);
      
      if (!mirna || !lncrna) {
        throw new Error(`Related mirna or lncrna not found for interaction ${interaction.id}`);
      }
      
      return {
        interaction,
        mirna,
        lncrna
      };
    }));
  }

  // Prediction-related methods
  async predictInteraction(input: PredictionInput): Promise<PredictionResult> {
    // Basic implementation of prediction algorithm
    const { mirnaSequence, lncrnaSequence, seedRegion, alignmentScore, mismatchPenalty, guWobble } = input;
    
    // Simple prediction logic
    // In a real implementation, this would use more complex algorithms
    const bindingSites = [];
    let totalMismatches = 0;
    let seedMatches = 0;
    
    // Sliding window approach for finding binding sites
    for (let i = 0; i <= lncrnaSequence.length - mirnaSequence.length; i++) {
      const lncrnaSubseq = lncrnaSequence.substring(i, i + mirnaSequence.length);
      
      // Count matches, mismatches, and G:U pairs
      let matches = 0;
      let mismatches = 0;
      let guPairs = 0;
      let seedMatch = true;
      
      // Alignment string
      let alignment = "";
      
      for (let j = 0; j < mirnaSequence.length; j++) {
        const mirnaBase = mirnaSequence[j].toUpperCase();
        const lncrnaBase = this.complementaryBase(lncrnaSubseq[j].toUpperCase());
        
        if (mirnaBase === lncrnaBase) {
          matches++;
          alignment += "|";
        } else if ((mirnaBase === "G" && lncrnaBase === "U") || (mirnaBase === "U" && lncrnaBase === "G")) {
          guPairs++;
          matches += guWobble;
          alignment += "○";
        } else {
          mismatches++;
          alignment += "×";
          
          // Check if mismatch is in seed region
          let seedStart = 1;
          let seedEnd = 7;
          
          if (seedRegion === "2-8") {
            seedStart = 1;
            seedEnd = 8;
          } else if (seedRegion === "1-8") {
            seedStart = 0;
            seedEnd = 8;
          }
          
          if (j >= seedStart && j < seedEnd) {
            seedMatch = false;
          }
        }
      }
      
      // Calculate score based on matches, mismatches, and G:U pairs
      const score = (matches - (mismatches * mismatchPenalty)) / mirnaSequence.length * 5;
      
      // Only consider if score is above threshold
      if (score >= alignmentScore) {
        bindingSites.push({
          mirnaStart: 0,
          mirnaEnd: mirnaSequence.length - 1,
          lncrnaStart: i,
          lncrnaEnd: i + mirnaSequence.length - 1,
          mirnaSequence,
          lncrnaSequence: lncrnaSubseq,
          alignment,
          score,
          mismatches,
          guPairs,
          seedMatch
        });
        
        totalMismatches += mismatches;
        if (seedMatch) seedMatches++;
      }
    }
    
    // Sort binding sites by score
    bindingSites.sort((a, b) => b.score - a.score);
    
    return {
      score: bindingSites.length > 0 ? bindingSites[0].score : 0,
      bindingSites,
      mirnaSequence,
      lncrnaSequence,
      totalMismatches,
      seedMatches
    };
  }
  
  // Helper method to get complementary base
  private complementaryBase(base: string): string {
    switch (base) {
      case "A": return "U";
      case "U": return "A";
      case "G": return "C";
      case "C": return "G";
      default: return "N";
    }
  }
}

// Import DatabaseStorage
import { DatabaseStorage } from "./database-storage";

// Export a singleton instance
// Use DatabaseStorage instead of MemStorage
export const storage = new DatabaseStorage();
