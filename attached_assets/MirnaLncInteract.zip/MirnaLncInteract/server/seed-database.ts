import { db } from "./db";
import { mirnas, lncrnas, interactions } from "@shared/schema";

async function seedDatabase() {
  console.log("Seeding database with initial data...");

  // Check if there's already data in the database
  const existingMirnas = await db.select().from(mirnas);
  
  if (existingMirnas.length > 0) {
    console.log("Database already has data, skipping seed process.");
    return;
  }

  // Sample miRNAs
  const mirnaData = [
    {
      name: "ath-miR156a-5p",
      sequence: "UGACAGAAGAGAGUGAGCAC",
      species: "Arabidopsis thaliana",
      source: "miRBase"
    },
    {
      name: "ath-miR156c-5p",
      sequence: "UUGACAGAAGAUAGAGAGCAC",
      species: "Arabidopsis thaliana",
      source: "miRBase"
    },
    {
      name: "ath-miR172e-3p",
      sequence: "GGAAUCUUGAUGAUGCUGCAU",
      species: "Arabidopsis thaliana",
      source: "miRBase"
    }
  ];

  // Sample lncRNAs
  const lncrnaData = [
    {
      name: "ENSG00000228630",
      sequence: "ACUGCUCACUCUCUCUUGUCAAGUUACGGUACGUCGAUUAGCCGAUUACGCGUGC",
      species: "Arabidopsis thaliana",
      location: "Chr5: 23456789-23459876"
    },
    {
      name: "AT4G13570",
      sequence: "AUCGUCAGACGCUGCAGCUGACGCUGACGUCGCUGCGAUUGCGAUGCGAUGCGAUC",
      species: "Arabidopsis thaliana",
      location: "Chr4: 7654321-7657654"
    },
    {
      name: "AT5G03345",
      sequence: "GCUAGUCGUAGCUGAUGCGAUGCAUGGCUGCUGCUAGCUAGCUGCUACGCUACGC",
      species: "Arabidopsis thaliana",
      location: "Chr5: 1234567-1237890"
    }
  ];

  // Insert miRNAs
  console.log("Inserting miRNAs...");
  const insertedMirnas = await db.insert(mirnas).values(mirnaData).returning({ id: mirnas.id });
  
  // Insert lncRNAs
  console.log("Inserting lncRNAs...");
  const insertedLncrnas = await db.insert(lncrnas).values(lncrnaData).returning({ id: lncrnas.id });

  // Sample interactions
  const interactionData = [
    {
      mirna_id: insertedMirnas[0].id, // ath-miR156a-5p
      lncrna_id: insertedLncrnas[0].id, // ENSG00000228630
      alignment: "UGACAGAAGAGAGUGAGCAC\n||||||||||||×||||||\nACUGCUCACUCUCUCUUGUCA",
      binding_site: "10-30",
      score: 4.2,
      method: "Computational",
      source: "Experimental"
    },
    {
      mirna_id: insertedMirnas[1].id, // ath-miR156c-5p
      lncrna_id: insertedLncrnas[1].id, // AT4G13570
      alignment: "UUGACAGAAGAUAGAGAGCAC\n|||||||||×||||||||||\nAUCGUCAGACGCUGCAGCUGA",
      binding_site: "5-25",
      score: 3.8,
      method: "Computational",
      source: "Predicted"
    },
    {
      mirna_id: insertedMirnas[0].id, // ath-miR156a-5p
      lncrna_id: insertedLncrnas[2].id, // AT5G03345
      alignment: "UGACAGAAGAGAGUGAGCAC\n||||||||×||||||×|||\nGCUAGUCGUAGCUGAUGCGAU",
      binding_site: "1-21",
      score: 2.9,
      method: "Computational",
      source: "Predicted"
    }
  ];

  // Insert interactions
  console.log("Inserting interactions...");
  await db.insert(interactions).values(interactionData);

  console.log("Database seeded successfully!");
}

// Execute the seed function
seedDatabase()
  .then(() => {
    console.log("Seed process completed.");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Error seeding database:", error);
    process.exit(1);
  });