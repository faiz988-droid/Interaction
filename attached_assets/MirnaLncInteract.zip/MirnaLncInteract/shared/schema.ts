import { pgTable, text, serial, integer, boolean, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// miRNA table
export const mirnas = pgTable("mirnas", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  sequence: text("sequence").notNull(),
  species: text("species").notNull().default("Arabidopsis thaliana"),
  source: text("source").notNull(),
});

// lncRNA table
export const lncrnas = pgTable("lncrnas", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  sequence: text("sequence").notNull(),
  species: text("species").notNull().default("Arabidopsis thaliana"),
  location: text("location"),
});

// interaction table
export const interactions = pgTable("interactions", {
  id: serial("id").primaryKey(),
  mirna_id: integer("mirna_id").notNull(),
  lncrna_id: integer("lncrna_id").notNull(),
  alignment: text("alignment").notNull(),
  binding_site: text("binding_site").notNull(),
  score: real("score").notNull(),
  method: text("method").notNull(),
  source: text("source").notNull(),
});

// Insert schemas
export const insertMirnaSchema = createInsertSchema(mirnas).omit({
  id: true,
});

export const insertLncrnaSchema = createInsertSchema(lncrnas).omit({
  id: true,
});

export const insertInteractionSchema = createInsertSchema(interactions).omit({
  id: true,
});

// Types
export type Mirna = typeof mirnas.$inferSelect;
export type InsertMirna = z.infer<typeof insertMirnaSchema>;

export type Lncrna = typeof lncrnas.$inferSelect;
export type InsertLncrna = z.infer<typeof insertLncrnaSchema>;

export type Interaction = typeof interactions.$inferSelect;
export type InsertInteraction = z.infer<typeof insertInteractionSchema>;

// Custom type for interaction with related entities
export type InteractionWithDetails = {
  interaction: Interaction;
  mirna: Mirna;
  lncrna: Lncrna;
};

// Custom prediction input types
export const predictionInputSchema = z.object({
  mirnaSequence: z.string().min(1, "miRNA sequence is required"),
  lncrnaSequence: z.string().min(1, "lncRNA sequence is required"),
  seedRegion: z.enum(["2-7", "2-8", "1-8"]).default("2-7"),
  alignmentScore: z.number().min(1).max(5).default(3),
  mismatchPenalty: z.number().min(0).max(2).default(1),
  guWobble: z.number().min(0).max(1).default(0.5),
});

export type PredictionInput = z.infer<typeof predictionInputSchema>;

// Custom prediction result type
export type PredictionResult = {
  score: number;
  bindingSites: Array<{
    mirnaStart: number;
    mirnaEnd: number;
    lncrnaStart: number;
    lncrnaEnd: number;
    mirnaSequence: string;
    lncrnaSequence: string;
    alignment: string;
    score: number;
    mismatches: number;
    guPairs: number;
    seedMatch: boolean;
  }>;
  mirnaSequence: string;
  lncrnaSequence: string;
  totalMismatches: number;
  seedMatches: number;
};

// Schema for search queries
export const searchQuerySchema = z.object({
  searchType: z.enum(["mirna", "lncrna", "gene"]),
  searchTerm: z.string().min(1, "Search term is required"),
});

export type SearchQuery = z.infer<typeof searchQuerySchema>;

// Schema for the users table - referenced from original schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
