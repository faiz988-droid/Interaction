import { PredictionInput, PredictionResult } from "@shared/schema";
import { apiRequest } from "./queryClient";

// Predict interactions between miRNA and lncRNA sequences
export async function predictInteractions(input: PredictionInput): Promise<PredictionResult> {
  const res = await apiRequest("POST", "/api/predict", input);
  return await res.json();
}

// Utility function to validate sequence format (A, U, G, C only)
export function validateSequence(sequence: string): boolean {
  return /^[AUGCaugc]+$/.test(sequence);
}

// Utility function to count mismatches in an alignment
export function countMismatches(alignment: string): number {
  return (alignment.match(/×/g) || []).length;
}

// Utility function to count G:U wobble pairs in an alignment
export function countGUPairs(alignment: string): number {
  return (alignment.match(/○/g) || []).length;
}

// Utility functions for seed region matches
export function getSeedRegionIndices(seedRegion: string): [number, number] {
  switch (seedRegion) {
    case "2-7":
      return [1, 6]; // 0-indexed
    case "2-8":
      return [1, 7];
    case "1-8":
      return [0, 7];
    default:
      return [1, 6]; // default to 2-7
  }
}

// Check if a given binding site has a seed match
export function hasSeedMatch(
  alignment: string,
  seedStart: number,
  seedEnd: number
): boolean {
  const seedAlignment = alignment.substring(seedStart, seedEnd + 1);
  // Seed match if no mismatches in seed region (× symbol)
  return !seedAlignment.includes("×");
}
