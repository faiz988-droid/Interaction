// Get the complementary RNA base
export function getComplementaryBase(base: string): string {
  const baseUpper = base.toUpperCase();
  switch (baseUpper) {
    case 'A':
      return 'U';
    case 'U':
      return 'A';
    case 'G':
      return 'C';
    case 'C':
      return 'G';
    default:
      return 'N'; // For any non-standard base
  }
}

// Get the complement of an entire RNA sequence
export function getComplementarySequence(sequence: string): string {
  return sequence
    .split('')
    .map(base => getComplementaryBase(base))
    .join('');
}

// Check if two bases form a G-U wobble pair
export function isGUWobblePair(base1: string, base2: string): boolean {
  const b1 = base1.toUpperCase();
  const b2 = base2.toUpperCase();
  return (b1 === 'G' && b2 === 'U') || (b1 === 'U' && b2 === 'G');
}

// Format sequence with linebreaks for display purposes
export function formatSequence(sequence: string, lineLength: number = 80): string {
  if (!sequence) return '';
  
  const chunks: string[] = [];
  for (let i = 0; i < sequence.length; i += lineLength) {
    chunks.push(sequence.slice(i, i + lineLength));
  }
  return chunks.join('\n');
}

// Truncate long sequences for display
export function truncateSequence(sequence: string, maxLength: number = 50): string {
  if (sequence.length <= maxLength) return sequence;
  return `${sequence.substring(0, maxLength)}...`;
}

// Calculate base pair match score (perfect match, G-U wobble, or mismatch)
export function calculateBaseMatchScore(
  base1: string,
  base2: string,
  perfectMatchScore: number = 1,
  guWobbleScore: number = 0.5,
  mismatchScore: number = 0
): number {
  const b1 = base1.toUpperCase();
  const b2 = base2.toUpperCase();
  
  // Perfect match
  if (getComplementaryBase(b1) === b2) {
    return perfectMatchScore;
  }
  
  // G-U wobble pair
  if (isGUWobblePair(b1, b2)) {
    return guWobbleScore;
  }
  
  // Mismatch
  return mismatchScore;
}

// Get alignment character for visualization
export function getAlignmentChar(base1: string, base2: string): string {
  const b1 = base1.toUpperCase();
  const b2 = base2.toUpperCase();
  
  // Perfect match
  if (getComplementaryBase(b1) === b2) {
    return '|';
  }
  
  // G-U wobble pair
  if (isGUWobblePair(b1, b2)) {
    return '○';
  }
  
  // Mismatch
  return '×';
}

// Validate RNA sequence (contains only A, U, G, C)
export function isValidRNASequence(sequence: string): boolean {
  return /^[AUGCaugc]+$/.test(sequence);
}
