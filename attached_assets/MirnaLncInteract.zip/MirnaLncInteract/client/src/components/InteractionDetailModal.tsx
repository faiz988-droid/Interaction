import React, { createContext, useState, useContext } from "react";
import { InteractionWithDetails } from "@shared/schema";
import SequenceAlignment from "./SequenceAlignment";

interface InteractionContextType {
  isModalOpen: boolean;
  currentInteraction: InteractionWithDetails | null;
  openModal: (interaction: InteractionWithDetails) => void;
  closeModal: () => void;
}

const InteractionContext = createContext<InteractionContextType | undefined>(undefined);

export const useInteraction = (): InteractionContextType => {
  const context = useContext(InteractionContext);
  if (!context) {
    throw new Error("useInteraction must be used within an InteractionProvider");
  }
  return context;
};

export const InteractionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentInteraction, setCurrentInteraction] = useState<InteractionWithDetails | null>(null);

  const openModal = (interaction: InteractionWithDetails) => {
    setCurrentInteraction(interaction);
    setIsModalOpen(true);
    document.body.style.overflow = "hidden";
  };

  const closeModal = () => {
    setIsModalOpen(false);
    document.body.style.overflow = "auto";
  };

  return (
    <InteractionContext.Provider value={{ isModalOpen, currentInteraction, openModal, closeModal }}>
      {children}
      <InteractionDetailModal />
    </InteractionContext.Provider>
  );
};

const InteractionDetailModal: React.FC = () => {
  const { isModalOpen, currentInteraction, closeModal } = useInteraction();

  const handleExportInteraction = () => {
    if (!currentInteraction) return;

    const data = {
      mirna: {
        id: currentInteraction.mirna.name,
        species: currentInteraction.mirna.species,
        sequence: currentInteraction.mirna.sequence,
      },
      lncrna: {
        id: currentInteraction.lncrna.name,
        location: currentInteraction.lncrna.location,
        sequence: currentInteraction.lncrna.sequence,
      },
      interaction: {
        score: currentInteraction.interaction.score,
        source: currentInteraction.interaction.source,
        alignment: currentInteraction.interaction.alignment,
        binding_site: currentInteraction.interaction.binding_site,
      },
    };

    const dataStr = JSON.stringify(data, null, 2);
    const dataUri = `data:application/json;charset=utf-8,${encodeURIComponent(dataStr)}`;
    
    const exportFileDefaultName = `${currentInteraction.mirna.name}_${currentInteraction.lncrna.name}_interaction.json`;
    
    const linkElement = document.createElement("a");
    linkElement.setAttribute("href", dataUri);
    linkElement.setAttribute("download", exportFileDefaultName);
    linkElement.click();
  };

  if (!isModalOpen || !currentInteraction) return null;

  // Parse alignment string
  const alignmentLines = currentInteraction.interaction.alignment.split('\n');
  const mirnaSeq = alignmentLines[0];
  const alignSymbols = alignmentLines[1];
  const lncrnaSeq = alignmentLines[2];

  const mismatchCount = (alignSymbols.match(/×/g) || []).length;
  
  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
      onClick={(e) => {
        if (e.target === e.currentTarget) closeModal();
      }}
    >
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center border-b p-4">
          <h3 className="font-display font-bold text-xl">Interaction Details</h3>
          <button 
            className="text-neutral-500 hover:text-neutral-700 transition-colors"
            onClick={closeModal}
          >
            <i className="fas fa-times text-xl"></i>
          </button>
        </div>
        
        <div className="p-6">
          <div className="grid md:grid-cols-2 gap-6 mb-6">
            <div>
              <h4 className="font-display font-semibold text-lg mb-3">miRNA Information</h4>
              <div className="bg-neutral-50 p-4 rounded-lg">
                <div className="mb-3">
                  <span className="font-semibold">ID:</span>{" "}
                  <span>{currentInteraction.mirna.name}</span>
                </div>
                <div className="mb-3">
                  <span className="font-semibold">Species:</span>{" "}
                  <span>{currentInteraction.mirna.species}</span>
                </div>
                <div>
                  <span className="font-semibold block mb-1">Sequence:</span>
                  <div className="font-mono text-sm bg-white p-2 rounded border overflow-x-auto">
                    {currentInteraction.mirna.sequence}
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="font-display font-semibold text-lg mb-3">lncRNA Information</h4>
              <div className="bg-neutral-50 p-4 rounded-lg">
                <div className="mb-3">
                  <span className="font-semibold">ID:</span>{" "}
                  <span>{currentInteraction.lncrna.name}</span>
                </div>
                <div className="mb-3">
                  <span className="font-semibold">Location:</span>{" "}
                  <span>{currentInteraction.lncrna.location}</span>
                </div>
                <div>
                  <span className="font-semibold block mb-1">Sequence:</span>
                  <div className="font-mono text-sm bg-white p-2 rounded border overflow-x-auto">
                    {currentInteraction.lncrna.sequence}
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mb-6">
            <h4 className="font-display font-semibold text-lg mb-3">Interaction Details</h4>
            <div className="bg-neutral-50 p-4 rounded-lg">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div>
                  <span className="text-sm text-neutral-500">Score</span>
                  <div className="font-semibold text-lg">{currentInteraction.interaction.score.toFixed(1)}</div>
                </div>
                <div>
                  <span className="text-sm text-neutral-500">Source</span>
                  <div className="font-semibold text-lg">{currentInteraction.interaction.source}</div>
                </div>
                <div>
                  <span className="text-sm text-neutral-500">Seed Match</span>
                  <div className="font-semibold text-lg">2-7</div>
                </div>
                <div>
                  <span className="text-sm text-neutral-500">Mismatches</span>
                  <div className="font-semibold text-lg">{mismatchCount}</div>
                </div>
              </div>
              
              <h5 className="font-semibold mb-2">Binding Alignment:</h5>
              <div className="bg-white p-4 rounded border">
                <SequenceAlignment 
                  mirnaSequence={mirnaSeq} 
                  lncrnaSequence={lncrnaSeq} 
                  alignment={alignSymbols} 
                />
              </div>
            </div>
          </div>
          
          <div className="pt-4 border-t flex justify-end">
            <button 
              className="bg-neutral-200 hover:bg-neutral-300 text-neutral-700 font-semibold py-2 px-4 rounded-lg mr-3 transition-colors" 
              onClick={closeModal}
            >
              Close
            </button>
            <button 
              className="bg-secondary hover:bg-secondary-dark text-white font-semibold py-2 px-4 rounded-lg transition-colors"
              onClick={handleExportInteraction}
            >
              <i className="fas fa-download mr-1"></i> Export Data
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
