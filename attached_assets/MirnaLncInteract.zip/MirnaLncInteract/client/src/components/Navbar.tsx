import { useState } from "react";
import { Link, useLocation } from "wouter";

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [location] = useLocation();

  const toggleMobileMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/browser", label: "Interaction Browser" },
    { href: "/prediction", label: "Prediction Tool" },
    { href: "/about", label: "About" },
  ];

  return (
    <nav className="bg-primary shadow-md">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <i className="fas fa-dna text-white text-2xl"></i>
          <Link href="/">
            <span className="text-white font-display font-bold text-xl cursor-pointer">PlantmiR-lncRNA</span>
          </Link>
        </div>
        <div className="hidden md:flex space-x-6 text-white">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href}>
              <span
                className={`hover:text-accent transition-colors cursor-pointer ${
                  location === link.href ? "text-accent" : ""
                }`}
              >
                {link.label}
              </span>
            </Link>
          ))}
        </div>
        <div className="md:hidden">
          <button
            className="text-white focus:outline-none"
            onClick={toggleMobileMenu}
          >
            <i className="fas fa-bars text-xl"></i>
          </button>
        </div>
      </div>
      {/* Mobile menu */}
      <div
        className={`md:hidden ${
          isMenuOpen ? "block" : "hidden"
        } bg-primary-dark`}
      >
        <div className="container mx-auto px-4 py-2 flex flex-col space-y-3 text-white">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href}>
              <span
                className={`py-2 hover:text-accent transition-colors cursor-pointer block ${
                  location === link.href ? "text-accent" : ""
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                {link.label}
              </span>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}
