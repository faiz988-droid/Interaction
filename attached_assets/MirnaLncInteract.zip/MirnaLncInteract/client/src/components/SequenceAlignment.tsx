import React from "react";

interface SequenceAlignmentProps {
  mirnaSequence: string;
  lncrnaSequence: string;
  alignment: string;
  position?: string;
}

const SequenceAlignment: React.FC<SequenceAlignmentProps> = ({ 
  mirnaSequence, 
  lncrnaSequence, 
  alignment,
  position
}) => {
  // Process sequences and alignment
  const mirnaChars = mirnaSequence.split("");
  const lncrnaChars = lncrnaSequence.split("");
  const alignChars = alignment.split("");

  // Helper to determine nucleotide class
  const getNucleotideClass = (char: string, isMatch: boolean, isGUPair: boolean) => {
    if (isMatch) return "nucleotide-match";
    if (isGUPair) return "nucleotide-gu-pair";
    return "nucleotide-mismatch";
  };

  return (
    <div className="binding-site relative mb-6">
      <div className="text-sm text-neutral-500 mb-1">miRNA 5'</div>
      <div className="font-mono">
        {mirnaChars.map((char, idx) => {
          const isMatch = alignChars[idx] === "|";
          const isGUPair = alignChars[idx] === "○";
          return (
            <span 
              key={`mirna-${idx}`} 
              className={getNucleotideClass(char, isMatch, isGUPair)}
            >
              {char}
            </span>
          );
        })}
        <span className="text-neutral-500">3'</span>
      </div>
      
      <div className="font-mono text-center">
        {alignChars.map((char, idx) => (
          <span key={`align-${idx}`}>
            {char === "|" ? "|" : char === "○" ? "○" : "×"}
          </span>
        ))}
        <span></span>
      </div>
      
      <div className="font-mono">
        {lncrnaChars.map((char, idx) => {
          const isMatch = alignChars[idx] === "|";
          const isGUPair = alignChars[idx] === "○";
          return (
            <span 
              key={`lncrna-${idx}`} 
              className={getNucleotideClass(char, isMatch, isGUPair)}
            >
              {char}
            </span>
          );
        })}
        <span className="text-neutral-500">5'</span>
      </div>
      
      <div className="text-sm text-neutral-500 mt-1">
        lncRNA 3' {position && `(Position: ${position})`}
      </div>
      
      <div className="highlight" style={{ left: "10px", width: `${alignChars.length * 10}px` }}></div>
      
      <style jsx>{`
        .binding-site {
          position: relative;
          font-family: 'Roboto Mono', monospace;
          letter-spacing: 0.5px;
          line-height: 2;
        }
        .binding-site .highlight {
          position: absolute;
          height: 2px;
          background-color: #8bc34a;
          bottom: -2px;
          transition: width 0.3s ease;
        }
        .nucleotide-match {
          color: #2e7d32;
          font-weight: 600;
        }
        .nucleotide-mismatch {
          color: #f44336;
        }
        .nucleotide-gu-pair {
          color: #ff9800;
        }
      `}</style>
      
      <div className="text-sm mt-4">
        <div className="mb-1">
          <span className="inline-block w-4 h-4 bg-[#2e7d32] rounded-full align-middle mr-2"></span>
          <span>Perfect match</span>
        </div>
        <div className="mb-1">
          <span className="inline-block w-4 h-4 bg-[#f44336] rounded-full align-middle mr-2"></span>
          <span>Mismatch</span>
        </div>
        <div>
          <span className="inline-block w-4 h-4 bg-[#ff9800] rounded-full align-middle mr-2"></span>
          <span>G:U wobble pair</span>
        </div>
      </div>
    </div>
  );
};

export default SequenceAlignment;
