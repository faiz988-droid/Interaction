import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-neutral-800 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <i className="fas fa-dna text-accent text-2xl"></i>
              <span className="font-display font-bold text-xl">PlantmiR-lncRNA</span>
            </div>
            <p className="text-neutral-300 text-sm">
              A comprehensive database and prediction tool for plant microRNA-lncRNA interactions.
            </p>
          </div>
          
          <div>
            <h4 className="font-display font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-neutral-300">
              <li>
                <Link href="/">
                  <span className="hover:text-accent transition-colors cursor-pointer">Home</span>
                </Link>
              </li>
              <li>
                <Link href="/browser">
                  <span className="hover:text-accent transition-colors cursor-pointer">Interaction Browser</span>
                </Link>
              </li>
              <li>
                <Link href="/prediction">
                  <span className="hover:text-accent transition-colors cursor-pointer">Prediction Tool</span>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <span className="hover:text-accent transition-colors cursor-pointer">About</span>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-display font-semibold mb-4">Resources</h4>
            <ul className="space-y-2 text-neutral-300">
              <li>
                <Link href="/about">
                  <span className="hover:text-accent transition-colors cursor-pointer">API Documentation</span>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <span className="hover:text-accent transition-colors cursor-pointer">User Guide</span>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <span className="hover:text-accent transition-colors cursor-pointer">Download Data</span>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <span className="hover:text-accent transition-colors cursor-pointer">Publication</span>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-display font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-neutral-300">
              <li className="flex items-center">
                <i className="fas fa-user text-accent mr-2"></i>
                <span className="hover:text-accent transition-colors">
                  Owner: Muskan
                </span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-phone text-accent mr-2"></i>
                <span className="hover:text-accent transition-colors">
                  Contact Number: Will be updated by owner soon
                </span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-envelope text-accent mr-2"></i>
                <a href="mailto:contact@plantmir-lncrna.org" className="hover:text-accent transition-colors">
                  contact@plantmir-lncrna.org
                </a>
              </li>
              <li className="flex items-center">
                <i className="fab fa-github text-accent mr-2"></i>
                <span className="hover:text-accent transition-colors">
                  GitHub Repository: Will be uploaded soon
                </span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-neutral-700 mt-8 pt-6 text-center text-neutral-400 text-sm">
          <p>© {new Date().getFullYear()} PlantmiR-lncRNA Database. All rights reserved.</p>
          <p className="mt-2">Developed by Muskan at the Plant Genomics Research Institute.</p>
        </div>
      </div>
    </footer>
  );
}
