import { useState, useEffect } from "react";
import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import Home from "@/pages/Home";
import InteractionBrowser from "@/pages/InteractionBrowser";
import PredictionTool from "@/pages/PredictionTool";
import About from "@/pages/About";
import { InteractionProvider } from "@/components/InteractionDetailModal";

function Router() {
  const [location] = useLocation();
  
  // Scroll to top when navigating
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);

  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/browser" component={InteractionBrowser} />
      <Route path="/prediction" component={PredictionTool} />
      <Route path="/about" component={About} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <InteractionProvider>
          <div className="flex flex-col min-h-screen">
            <Navbar />
            <main className="flex-grow">
              <Router />
            </main>
            <Footer />
          </div>
          <Toaster />
        </InteractionProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
