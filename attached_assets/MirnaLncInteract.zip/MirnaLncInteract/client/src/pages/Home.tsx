import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { 
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { truncateSequence } from "@/lib/sequenceUtils";
import { queryClient } from "@/lib/queryClient";
import { InteractionWithDetails } from "@shared/schema";

export default function Home() {
  // Create a POST endpoint for the recent interactions
  const searchRecentInteractions = async () => {
    const response = await fetch('/api/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ searchType: 'mirna', searchTerm: 'miR' }),
      credentials: 'include'
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch interactions');
    }
    
    const data = await response.json();
    // Return only the first 5 interactions
    return data.slice(0, 5);
  };
  
  // Query to fetch recent interactions
  const { data: recentInteractions = [], isLoading } = useQuery({
    queryKey: ['recentInteractions'],
    queryFn: searchRecentInteractions
  });

  return (
    <section className="py-16 bg-gradient-to-b from-primary-light/10 to-neutral-50">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-display font-bold text-primary mb-4">
              Plant miRNA-lncRNA Interaction Database
            </h1>
            <p className="text-lg mb-6">
              Explore and predict microRNA and long non-coding RNA interactions in{" "}
              <em>Arabidopsis thaliana</em> with our integrated in silico prediction tool.
            </p>
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4">
              <Link href="/browser">
                <span className="bg-primary hover:bg-primary-dark text-white font-semibold py-3 px-6 rounded-lg shadow transition-colors text-center cursor-pointer block">
                  Browse Interactions
                </span>
              </Link>
              <Link href="/prediction">
                <span className="bg-white hover:bg-gray-100 text-primary border-2 border-primary font-semibold py-3 px-6 rounded-lg shadow transition-colors text-center cursor-pointer block">
                  Predict New Interactions
                </span>
              </Link>
            </div>
          </div>
          <div className="flex justify-center">
            <img
              src="https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400&q=80"
              alt="Arabidopsis thaliana plant"
              className="rounded-lg shadow-lg max-w-full h-auto"
            />
          </div>
        </div>

        {/* Database Statistics */}
        <div className="mt-16 p-6 bg-white rounded-lg shadow">
          <h2 className="text-2xl font-display font-bold text-primary mb-6">Database Statistics</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary">217</div>
              <div className="text-sm mt-2">Experimentally Validated Interactions</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary">14,632</div>
              <div className="text-sm mt-2">Predicted Interactions</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary">42</div>
              <div className="text-sm mt-2">miRNAs</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-primary">326</div>
              <div className="text-sm mt-2">lncRNAs</div>
            </div>
          </div>
        </div>

        {/* Recent Interactions Table */}
        <div className="mt-8 p-6 bg-white rounded-lg shadow">
          <h2 className="text-2xl font-display font-bold text-primary mb-6">Recent Interactions</h2>
          
          <Table>
            <TableCaption>A list of recent miRNA-lncRNA interactions in the database.</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>miRNA</TableHead>
                <TableHead>lncRNA</TableHead>
                <TableHead>Score</TableHead>
                <TableHead>Method</TableHead>
                <TableHead>Source</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-4">Loading interactions...</TableCell>
                </TableRow>
              ) : recentInteractions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-4">No interactions found</TableCell>
                </TableRow>
              ) : (
                recentInteractions.map((item: InteractionWithDetails) => (
                  <TableRow key={item.interaction.id}>
                    <TableCell className="font-medium">{item.mirna.name}</TableCell>
                    <TableCell>{item.lncrna.name}</TableCell>
                    <TableCell>{item.interaction.score.toFixed(1)}</TableCell>
                    <TableCell>{item.interaction.method}</TableCell>
                    <TableCell>{item.interaction.source}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
          
          <div className="mt-4 text-center">
            <Link href="/browser">
              <span className="text-primary hover:text-primary-dark font-semibold transition-colors cursor-pointer inline-flex items-center">
                View All Interactions
                <i className="fas fa-arrow-right ml-2"></i>
              </span>
            </Link>
          </div>
        </div>

        <div className="mt-16 grid md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-lg shadow hover:shadow-md transition-shadow">
            <div className="text-primary text-3xl mb-4">
              <i className="fas fa-database"></i>
            </div>
            <h3 className="text-xl font-display font-semibold mb-2">
              Comprehensive Database
            </h3>
            <p>
              Access a curated collection of experimentally validated and computationally 
              predicted miRNA-lncRNA interactions in Arabidopsis thaliana.
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow hover:shadow-md transition-shadow">
            <div className="text-primary text-3xl mb-4">
              <i className="fas fa-search"></i>
            </div>
            <h3 className="text-xl font-display font-semibold mb-2">
              Advanced Search
            </h3>
            <p>
              Quickly find interactions by miRNA name, lncRNA identifier, or gene ID 
              with our powerful search functionality.
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg shadow hover:shadow-md transition-shadow">
            <div className="text-primary text-3xl mb-4">
              <i className="fas fa-calculator"></i>
            </div>
            <h3 className="text-xl font-display font-semibold mb-2">
              Prediction Tool
            </h3>
            <p>
              Predict interactions between your custom miRNA and lncRNA sequences 
              with our alignment algorithm.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
