import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { PredictionInput, PredictionResult } from "@shared/schema";
import { predictInteractions } from "@/lib/prediction";
import { isValidRNASequence } from "@/lib/sequenceUtils";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import SequenceAlignment from "@/components/SequenceAlignment";

// Validation schema for the form
const formSchema = z.object({
  mirnaSequence: z
    .string()
    .min(1, "miRNA sequence is required")
    .refine((val) => isValidRNASequence(val), {
      message: "Sequence must contain only A, U, G, C nucleotides",
    }),
  lncrnaSequence: z
    .string()
    .min(1, "lncRNA sequence is required")
    .refine((val) => isValidRNASequence(val), {
      message: "Sequence must contain only A, U, G, C nucleotides",
    }),
  seedRegion: z.enum(["2-7", "2-8", "1-8"]),
  alignmentScore: z.number().min(1).max(5),
  mismatchPenalty: z.enum(["0.5", "1.0", "1.5"]).transform(val => parseFloat(val)),
  guWobble: z.enum(["0.5", "0", "1"]).transform(val => parseFloat(val)),
});

export default function PredictionTool() {
  const [predictionResult, setPredictionResult] = useState<PredictionResult | null>(null);
  const [isPredictionResultsVisible, setIsPredictionResultsVisible] = useState(false);
  const { toast } = useToast();

  // Form setup
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      mirnaSequence: "",
      lncrnaSequence: "",
      seedRegion: "2-7",
      alignmentScore: 3.0,
      mismatchPenalty: 1.0,
      guWobble: 0.5,
    },
  });

  // Mutation for predicting interactions
  const predictionMutation = useMutation({
    mutationFn: predictInteractions,
    onSuccess: (data) => {
      setPredictionResult(data);
      setIsPredictionResultsVisible(true);
      
      if (data.bindingSites.length === 0) {
        toast({
          title: "No interactions found",
          description: "Try different sequences or adjust the parameters",
          variant: "default",
        });
      } else {
        toast({
          title: "Prediction completed",
          description: `Found ${data.bindingSites.length} potential binding sites`,
          variant: "default",
        });
      }
      
      // Scroll to results
      setTimeout(() => {
        const resultsElement = document.getElementById("prediction-results");
        if (resultsElement) {
          resultsElement.scrollIntoView({ behavior: "smooth", block: "start" });
        }
      }, 100);
    },
    onError: (error) => {
      toast({
        title: "Prediction failed",
        description: error instanceof Error ? error.message : "An error occurred during prediction",
        variant: "destructive",
      });
    },
  });

  // Form submission handler
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    // Convert form values to PredictionInput
    const input: PredictionInput = {
      mirnaSequence: values.mirnaSequence.toUpperCase(),
      lncrnaSequence: values.lncrnaSequence.toUpperCase(),
      seedRegion: values.seedRegion,
      alignmentScore: values.alignmentScore,
      mismatchPenalty: values.mismatchPenalty,
      guWobble: values.guWobble,
    };
    
    predictionMutation.mutate(input);
  };

  // Reset form handler
  const handleReset = () => {
    form.reset();
    setPredictionResult(null);
    setIsPredictionResultsVisible(false);
  };

  return (
    <section id="prediction" className="py-16 bg-neutral-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-display font-bold text-primary mb-2">
            Prediction Tool
          </h2>
          <p className="text-lg max-w-3xl mx-auto">
            Upload your own miRNA and lncRNA sequences to predict potential interactions.
          </p>
        </div>

        <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-md p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} id="prediction-form">
              <FormField
                control={form.control}
                name="mirnaSequence"
                render={({ field }) => (
                  <FormItem className="mb-6">
                    <FormLabel className="text-sm font-semibold">
                      miRNA Sequence
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Enter miRNA sequence (e.g., UGACAGAAGAGAGUGAGCAC)"
                        rows={3}
                        className="font-mono"
                        {...field}
                      />
                    </FormControl>
                    <div className="mt-1 text-sm text-neutral-500">
                      Enter a single miRNA sequence in 5' to 3' orientation using A, U, G, C nucleotides.
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="lncrnaSequence"
                render={({ field }) => (
                  <FormItem className="mb-6">
                    <FormLabel className="text-sm font-semibold">
                      lncRNA Sequence
                    </FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Enter lncRNA sequence"
                        rows={5}
                        className="font-mono"
                        {...field}
                      />
                    </FormControl>
                    <div className="mt-1 text-sm text-neutral-500">
                      Enter a single lncRNA sequence in 5' to 3' orientation using A, U, G, C nucleotides.
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="mb-6">
                <h4 className="font-display font-semibold text-lg mb-3">
                  Advanced Parameters
                </h4>
                <div className="grid md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="seedRegion"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-semibold">
                          Seed Region
                        </FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select seed region" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="2-7">2-7 (Default)</SelectItem>
                            <SelectItem value="2-8">2-8 (Extended)</SelectItem>
                            <SelectItem value="1-8">1-8 (Full seed)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="alignmentScore"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-semibold">
                          Minimum Alignment Score
                        </FormLabel>
                        <FormControl>
                          <Slider
                            min={1}
                            max={5}
                            step={0.1}
                            value={[field.value]}
                            onValueChange={(values) => field.onChange(values[0])}
                          />
                        </FormControl>
                        <div className="flex justify-between text-sm text-neutral-500">
                          <span>1.0</span>
                          <span>{field.value.toFixed(1)}</span>
                          <span>5.0</span>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="mismatchPenalty"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-semibold">
                          Mismatch Penalty
                        </FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value.toString()}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select mismatch penalty" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="0.5">0.5 (Low)</SelectItem>
                            <SelectItem value="1.0">1.0 (Medium)</SelectItem>
                            <SelectItem value="1.5">1.5 (High)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="guWobble"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm font-semibold">
                          G:U Wobble Pairing
                        </FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value.toString()}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select G:U wobble handling" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="0.5">Count as 0.5 match</SelectItem>
                            <SelectItem value="0">Count as mismatch</SelectItem>
                            <SelectItem value="1">Count as full match</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <div className="flex justify-center md:justify-end mt-8">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handleReset}
                  className="mr-4"
                >
                  Reset
                </Button>
                <Button
                  type="submit"
                  className="bg-primary hover:bg-primary-dark"
                  disabled={predictionMutation.isPending}
                >
                  {predictionMutation.isPending ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i> Processing...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-calculator mr-2"></i> Predict Interactions
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>

          {isPredictionResultsVisible && predictionResult && (
            <div id="prediction-results" className="mt-12">
              <div className="border-t pt-6">
                <h3 className="font-display font-semibold text-xl mb-6">
                  Prediction Results
                </h3>

                <div className="bg-neutral-50 p-6 rounded-lg">
                  <div className="grid md:grid-cols-4 gap-4 mb-6">
                    <div>
                      <span className="text-sm text-neutral-500">Prediction Score</span>
                      <div className="font-semibold text-lg">
                        {predictionResult.score.toFixed(1)}
                      </div>
                    </div>
                    <div>
                      <span className="text-sm text-neutral-500">Binding Sites</span>
                      <div className="font-semibold text-lg">
                        {predictionResult.bindingSites.length}
                      </div>
                    </div>
                    <div>
                      <span className="text-sm text-neutral-500">Seed Matches</span>
                      <div className="font-semibold text-lg">
                        {predictionResult.seedMatches}
                      </div>
                    </div>
                    <div>
                      <span className="text-sm text-neutral-500">Mismatches</span>
                      <div className="font-semibold text-lg">
                        {predictionResult.totalMismatches}
                      </div>
                    </div>
                  </div>

                  {predictionResult.bindingSites.length > 0 && (
                    <>
                      <h4 className="font-display font-semibold text-lg mb-3">
                        Top Binding Site:
                      </h4>
                      <div className="bg-white p-4 rounded border mb-6">
                        <SequenceAlignment
                          mirnaSequence={predictionResult.bindingSites[0].mirnaSequence}
                          lncrnaSequence={predictionResult.bindingSites[0].lncrnaSequence}
                          alignment={predictionResult.bindingSites[0].alignment}
                          position={`${predictionResult.bindingSites[0].lncrnaStart}-${predictionResult.bindingSites[0].lncrnaEnd}`}
                        />
                      </div>

                      <div className="flex justify-end">
                        <Button variant="outline" className="mr-3">
                          <i className="fas fa-expand-alt mr-1"></i> View All Sites
                        </Button>
                        <Button variant="default" className="bg-secondary hover:bg-secondary-dark">
                          <i className="fas fa-download mr-1"></i> Download Results
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
