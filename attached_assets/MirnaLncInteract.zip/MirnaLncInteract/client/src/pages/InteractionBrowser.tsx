import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { SearchQuery, InteractionWithDetails } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useInteraction } from "@/components/InteractionDetailModal";
import { useToast } from "@/hooks/use-toast";

export default function InteractionBrowser() {
  const [searchType, setSearchType] = useState<"mirna" | "lncrna" | "gene">("mirna");
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState<InteractionWithDetails[]>([]);
  const [isResultsVisible, setIsResultsVisible] = useState(false);
  const { openModal } = useInteraction();
  const { toast } = useToast();

  // Mutation for searching interactions
  const searchMutation = useMutation({
    mutationFn: async (query: SearchQuery) => {
      const res = await apiRequest("POST", "/api/search", query);
      return res.json() as Promise<InteractionWithDetails[]>;
    },
    onSuccess: (data) => {
      setSearchResults(data);
      setIsResultsVisible(true);
      
      if (data.length === 0) {
        toast({
          title: "No results found",
          description: "Try a different search term or search type.",
          variant: "destructive",
        });
      }
    },
    onError: (error) => {
      toast({
        title: "Search failed",
        description: error instanceof Error ? error.message : "An error occurred during search",
        variant: "destructive",
      });
    },
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchTerm.trim()) {
      toast({
        title: "Search term required",
        description: "Please enter a search term",
        variant: "destructive",
      });
      return;
    }
    
    searchMutation.mutate({
      searchType,
      searchTerm: searchTerm.trim(),
    });
  };

  const handleExampleClick = (example: string) => {
    setSearchTerm(example);
  };

  const viewInteractionDetails = (interaction: InteractionWithDetails) => {
    openModal(interaction);
  };

  return (
    <section id="browser" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-display font-bold text-primary mb-2">
            Interaction Browser
          </h2>
          <p className="text-lg max-w-3xl mx-auto">
            Search for miRNA-lncRNA interactions by miRNA, lncRNA, or gene identifier.
          </p>
        </div>

        <div className="max-w-4xl mx-auto bg-neutral-50 rounded-lg shadow-md p-6">
          <form onSubmit={handleSearch} className="mb-8">
            <div className="flex flex-col md:flex-row md:space-x-4 space-y-4 md:space-y-0">
              <div className="flex-1">
                <label htmlFor="search-type" className="block text-sm font-semibold mb-2">
                  Search by
                </label>
                <select
                  id="search-type"
                  className="w-full p-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition"
                  value={searchType}
                  onChange={(e) => setSearchType(e.target.value as any)}
                >
                  <option value="mirna">miRNA ID</option>
                  <option value="lncrna">lncRNA ID</option>
                  <option value="gene">Gene ID</option>
                </select>
              </div>
              <div className="flex-1">
                <label htmlFor="search-term" className="block text-sm font-semibold mb-2">
                  Search term
                </label>
                <input
                  type="text"
                  id="search-term"
                  placeholder="e.g., miR156, AT5G01180"
                  className="w-full p-3 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary transition"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <div className="self-end">
                <button
                  type="submit"
                  className="bg-primary hover:bg-primary-dark text-white font-semibold py-3 px-6 rounded-lg transition-colors"
                  disabled={searchMutation.isPending}
                >
                  {searchMutation.isPending ? (
                    <span className="flex items-center">
                      <i className="fas fa-spinner fa-spin mr-2"></i> Searching...
                    </span>
                  ) : (
                    <span className="flex items-center">
                      <i className="fas fa-search mr-2"></i> Search
                    </span>
                  )}
                </button>
              </div>
            </div>
          </form>

          <div className="bg-white p-4 rounded-lg border border-neutral-100 mb-4">
            <h3 className="font-display font-semibold text-lg mb-4">
              Example Searches
            </h3>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                className="text-sm bg-primary-light/10 text-primary hover:bg-primary-light/20 py-1 px-3 rounded-full transition-colors"
                onClick={() => handleExampleClick("ath-miR156a-5p")}
              >
                miR156
              </button>
              <button
                type="button"
                className="text-sm bg-primary-light/10 text-primary hover:bg-primary-light/20 py-1 px-3 rounded-full transition-colors"
                onClick={() => handleExampleClick("ath-miR172e-3p")}
              >
                miR172
              </button>
              <button
                type="button"
                className="text-sm bg-primary-light/10 text-primary hover:bg-primary-light/20 py-1 px-3 rounded-full transition-colors"
                onClick={() => handleExampleClick("ENSG00000228630")}
              >
                ENSG00000228630
              </button>
              <button
                type="button"
                className="text-sm bg-primary-light/10 text-primary hover:bg-primary-light/20 py-1 px-3 rounded-full transition-colors"
                onClick={() => handleExampleClick("AT4G13570")}
              >
                AT4G13570
              </button>
            </div>
          </div>

          {isResultsVisible && (
            <div id="search-results" className="mt-8">
              <h3 className="font-display font-semibold text-xl mb-4">
                Search Results{" "}
                <span className="text-neutral-500 text-base">
                  ({searchResults.length} interactions found)
                </span>
              </h3>

              <div className="overflow-x-auto">
                <table className="min-w-full bg-white border-collapse">
                  <thead>
                    <tr className="bg-neutral-100">
                      <th className="py-3 px-4 text-left text-sm font-semibold border-b">
                        miRNA
                      </th>
                      <th className="py-3 px-4 text-left text-sm font-semibold border-b">
                        lncRNA
                      </th>
                      <th className="py-3 px-4 text-left text-sm font-semibold border-b">
                        Score
                      </th>
                      <th className="py-3 px-4 text-left text-sm font-semibold border-b">
                        Source
                      </th>
                      <th className="py-3 px-4 text-left text-sm font-semibold border-b">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {searchResults.map((result) => (
                      <tr
                        key={result.interaction.id}
                        className="hover:bg-neutral-50 border-b transition-colors"
                      >
                        <td className="py-3 px-4">{result.mirna.name}</td>
                        <td className="py-3 px-4">{result.lncrna.name}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`inline-block px-2 py-1 text-xs font-semibold rounded-full ${
                              result.interaction.score >= 4
                                ? "bg-green-100 text-green-800"
                                : result.interaction.score >= 3
                                ? "bg-green-100 text-green-800"
                                : "bg-yellow-100 text-yellow-800"
                            }`}
                          >
                            {result.interaction.score.toFixed(1)}
                          </span>
                        </td>
                        <td className="py-3 px-4">{result.interaction.source}</td>
                        <td className="py-3 px-4">
                          <button
                            className="text-secondary hover:text-secondary-dark transition-colors"
                            onClick={() => viewInteractionDetails(result)}
                          >
                            <i className="fas fa-eye mr-1"></i> View
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {searchResults.length > 0 && (
                <div className="mt-6 flex justify-between items-center">
                  <div>
                    <span className="text-sm text-neutral-500">
                      Showing 1-{searchResults.length} of {searchResults.length} results
                    </span>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      className="px-3 py-1 rounded border border-neutral-300 text-neutral-500 bg-white hover:bg-neutral-50 transition-colors disabled:opacity-50"
                      disabled
                    >
                      <i className="fas fa-chevron-left"></i>
                    </button>
                    <button
                      className="px-3 py-1 rounded border border-neutral-300 text-neutral-500 bg-white hover:bg-neutral-50 transition-colors disabled:opacity-50"
                      disabled
                    >
                      <i className="fas fa-chevron-right"></i>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
