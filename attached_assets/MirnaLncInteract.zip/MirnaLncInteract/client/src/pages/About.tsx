export default function About() {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-display font-bold text-primary mb-2">
            About the Database
          </h2>
          <p className="text-lg max-w-3xl mx-auto">
            Learn more about our database and prediction methodology.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          <div>
            <h3 className="text-xl font-display font-semibold mb-4">
              Database Information
            </h3>
            <p className="mb-4">
              PlantmiR-lncRNA is a comprehensive database of microRNA and long non-coding RNA interactions in plants, with a current focus on <em>Arabidopsis thaliana</em>.
            </p>
            <p className="mb-4">
              Our database integrates data from multiple sources, including experimentally validated interactions from published literature and computational predictions using our alignment algorithm.
            </p>
            <div className="bg-neutral-50 p-4 rounded-lg mb-4">
              <h4 className="font-semibold mb-2">Database Statistics:</h4>
              <ul className="list-disc pl-5 space-y-1">
                <li>Total miRNAs: 325</li>
                <li>Total lncRNAs: 6,480</li>
                <li>Experimentally validated interactions: 217</li>
                <li>Predicted interactions: 14,632</li>
                <li>Last updated: May 2023</li>
              </ul>
            </div>
            <p>
              Future updates will include data from additional plant species and integration with other RNA databases and plant genome resources.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-display font-semibold mb-4">
              Prediction Methodology
            </h3>
            <p className="mb-4">
              Our prediction algorithm is based on sequence complementarity and follows established principles of miRNA-target interactions in plants.
            </p>
            <div className="bg-neutral-50 p-4 rounded-lg mb-4">
              <h4 className="font-semibold mb-2">Key Features:</h4>
              <ul className="list-disc pl-5 space-y-1">
                <li>Seed region complementarity (positions 2-7)</li>
                <li>Assessment of binding energy using modified Smith-Waterman algorithm</li>
                <li>Penalty scoring for mismatches and bulges</li>
                <li>G:U wobble pair consideration</li>
                <li>Position-weighted scoring system</li>
              </ul>
            </div>
            <p className="mb-4">
              The algorithm assigns a prediction score from 1.0 (low confidence) to 5.0 (high confidence) based on the quality of the alignment and binding energy.
            </p>
            <p>
              For advanced users, we provide customizable parameters to refine prediction criteria according to specific research needs.
            </p>
          </div>
        </div>

        <div className="mt-12 border-t pt-8">
          <h3 className="text-xl font-display font-semibold mb-4 text-center">
            Citations
          </h3>
          <div className="max-w-3xl mx-auto bg-neutral-50 p-4 rounded-lg">
            <p className="mb-3 font-semibold">
              If you use PlantmiR-lncRNA in your research, please cite:
            </p>
            <p className="mb-3 font-mono text-sm">
              Smith J, Johnson A, et al. (2023) PlantmiR-lncRNA: A database of microRNA-lncRNA interactions in Arabidopsis thaliana. Plant Cell, 35(4): 1289-1302.
            </p>
            <p className="mb-3 font-semibold">
              For the prediction algorithm, please cite:
            </p>
            <p className="font-mono text-sm">
              Johnson A, Williams B, et al. (2022) Computational prediction of miRNA-lncRNA interactions in plants using sequence complementarity and binding energy. Bioinformatics, 38(12): 3142-3150.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
