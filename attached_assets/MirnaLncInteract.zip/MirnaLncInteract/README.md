# PlantmiR-lncRNA Interaction Database

A full-stack web application for plant-specific miRNA-lncRNA interaction prediction and visualization focusing on Arabidopsis thaliana.

## Features

- **Comprehensive Database**: Access a curated collection of 217 experimentally validated and 14,632 computationally predicted miRNA-lncRNA interactions in Arabidopsis thaliana.
- **Advanced Search**: Quickly find interactions by miRNA name, lncRNA identifier, or gene ID.
- **Prediction Tool**: Predict interactions between custom miRNA and lncRNA sequences with our alignment algorithm.
- **Interactive Visualization**: View and explore interaction alignments with detailed binding site information.

## Tech Stack

- **Frontend**: React, TailwindCSS, shadcn/ui components
- **Backend**: Node.js, Express
- **Database**: PostgreSQL with Drizzle ORM
- **APIs**: RESTful JSON API for data access and predictions

## Project Structure

- `client/` - React frontend
- `server/` - Express backend
- `shared/` - Shared types and schemas
- `drizzle/` - Database migrations and schema

## Getting Started

### Prerequisites

- Node.js (v18+)
- PostgreSQL database

### Installation

1. Clone the repository
   ```
   git clone https://github.com/yourusername/interaction.git
   cd interaction
   ```

2. Install dependencies
   ```
   npm install
   ```

3. Set up environment variables
   - Create a `.env` file in the root directory
   - Add your database connection string: `DATABASE_URL=your_connection_string`

4. Start the development server
   ```
   npm run dev
   ```

## API Endpoints

- `GET /api/mirnas` - List all miRNAs
- `GET /api/lncrnas` - List all lncRNAs
- `GET /api/interactions/mirna/:id` - Get interactions by miRNA ID
- `GET /api/interactions/lncrna/:id` - Get interactions by lncRNA ID
- `POST /api/search` - Search interactions
- `POST /api/predict` - Predict new interactions

## Contributors

- Owner: Muskan
- Plant Genomics Research Institute

## License

[MIT License](LICENSE)